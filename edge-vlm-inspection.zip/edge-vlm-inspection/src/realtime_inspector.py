"""
Real-time Camera Inspector
Stream video and inspect frames on-demand using VLM.

Author: Pushkar Prashantrao Shinde
License: MIT
"""

import argparse
import time
import cv2
import numpy as np
from pathlib import Path
from datetime import datetime
from PIL import Image

from inspector import EdgeVLMInspector


class RealtimeInspector:
    """
    Real-time camera-based inspection using VLM.
    Press 'i' to inspect current frame, 'q' to quit.
    """
    
    def __init__(
        self,
        camera_id: int = 0,
        model_name: str = "llava-1.5-7b",
        quantize: bool = True,
        save_dir: str = "inspections",
    ):
        self.camera_id = camera_id
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(parents=True, exist_ok=True)
        
        print("[RealtimeInspector] Initializing VLM...")
        self.inspector = EdgeVLMInspector(
            model_name=model_name,
            quantize=quantize,
        )
        
        print("[RealtimeInspector] Opening camera...")
        self.cap = cv2.VideoCapture(camera_id)
        if not self.cap.isOpened():
            raise RuntimeError(f"Failed to open camera {camera_id}")
        
        # Set camera resolution
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        
        self.last_result = None
        self.inspecting = False
        
    def run(self, prompt_type: str = "pcb", custom_prompt: str = None):
        """
        Run the real-time inspection loop.
        
        Controls:
            'i' - Inspect current frame
            's' - Save current frame
            'q' - Quit
        """
        print("\n" + "=" * 50)
        print("REAL-TIME INSPECTOR")
        print("=" * 50)
        print("Controls:")
        print("  'i' - Inspect current frame")
        print("  's' - Save current frame")
        print("  'q' - Quit")
        print("=" * 50 + "\n")
        
        while True:
            ret, frame = self.cap.read()
            if not ret:
                print("Failed to read frame")
                break
            
            # Create display frame
            display = frame.copy()
            
            # Add status overlay
            self._draw_overlay(display)
            
            # Show frame
            cv2.imshow("Edge VLM Inspector", display)
            
            # Handle key presses
            key = cv2.waitKey(1) & 0xFF
            
            if key == ord('q'):
                break
            elif key == ord('i'):
                self._inspect_frame(frame, prompt_type, custom_prompt)
            elif key == ord('s'):
                self._save_frame(frame)
        
        self.cap.release()
        cv2.destroyAllWindows()
        
    def _inspect_frame(self, frame: np.ndarray, prompt_type: str, custom_prompt: str):
        """Inspect the current frame."""
        print("\n[Inspecting frame...]")
        self.inspecting = True
        
        # Convert BGR to RGB and then to PIL
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        pil_image = Image.fromarray(rgb_frame)
        
        # Run inspection
        result = self.inspector.inspect(
            image=pil_image,
            prompt=custom_prompt,
            prompt_type=prompt_type,
        )
        
        self.last_result = result
        self.inspecting = False
        
        # Print result
        print("\n" + "-" * 50)
        print(f"DEFECT: {'YES ⚠️' if result['has_defect'] else 'NO ✓'}")
        print(f"Time: {result['inference_time_ms']} ms")
        print(f"Analysis: {result['response']}")
        print("-" * 50 + "\n")
        
        # Save inspection
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        frame_path = self.save_dir / f"inspection_{timestamp}.jpg"
        cv2.imwrite(str(frame_path), frame)
        
        result_path = self.save_dir / f"inspection_{timestamp}.json"
        import json
        with open(result_path, "w") as f:
            json.dump(result, f, indent=2)
        
    def _save_frame(self, frame: np.ndarray):
        """Save current frame without inspection."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        frame_path = self.save_dir / f"frame_{timestamp}.jpg"
        cv2.imwrite(str(frame_path), frame)
        print(f"[Saved: {frame_path}]")
        
    def _draw_overlay(self, frame: np.ndarray):
        """Draw status overlay on frame."""
        h, w = frame.shape[:2]
        
        # Status bar background
        cv2.rectangle(frame, (0, 0), (w, 40), (0, 0, 0), -1)
        
        # Status text
        if self.inspecting:
            status = "INSPECTING..."
            color = (0, 255, 255)  # Yellow
        elif self.last_result:
            if self.last_result.get("has_defect"):
                status = f"DEFECT DETECTED | {self.last_result['inference_time_ms']}ms"
                color = (0, 0, 255)  # Red
            else:
                status = f"PASS | {self.last_result['inference_time_ms']}ms"
                color = (0, 255, 0)  # Green
        else:
            status = "Press 'i' to inspect | 'q' to quit"
            color = (255, 255, 255)  # White
        
        cv2.putText(frame, status, (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        
        # Last analysis (if exists)
        if self.last_result and not self.inspecting:
            response = self.last_result.get("response", "")[:100]
            y_offset = h - 60
            
            # Background for text
            cv2.rectangle(frame, (0, y_offset - 10), (w, h), (0, 0, 0), -1)
            
            # Wrap text
            words = response.split()
            lines = []
            current_line = []
            for word in words:
                current_line.append(word)
                if len(" ".join(current_line)) > 80:
                    lines.append(" ".join(current_line[:-1]))
                    current_line = [word]
            if current_line:
                lines.append(" ".join(current_line))
            
            for i, line in enumerate(lines[:2]):
                cv2.putText(
                    frame, line, (10, y_offset + i * 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1
                )


def main():
    parser = argparse.ArgumentParser(description="Real-time VLM Inspector")
    parser.add_argument("--camera", "-c", type=int, default=0, help="Camera ID")
    parser.add_argument("--model", "-m", type=str, default="llava-1.5-7b", help="Model name")
    parser.add_argument("--type", "-t", type=str, default="pcb", help="Inspection type")
    parser.add_argument("--prompt", "-p", type=str, default=None, help="Custom prompt")
    parser.add_argument("--no-quantize", action="store_true", help="Disable quantization")
    parser.add_argument("--save-dir", "-s", type=str, default="inspections", help="Save directory")
    
    args = parser.parse_args()
    
    inspector = RealtimeInspector(
        camera_id=args.camera,
        model_name=args.model,
        quantize=not args.no_quantize,
        save_dir=args.save_dir,
    )
    
    inspector.run(prompt_type=args.type, custom_prompt=args.prompt)


if __name__ == "__main__":
    main()
