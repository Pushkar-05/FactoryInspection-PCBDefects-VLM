"""
Edge VLM Industrial Inspector
Zero-shot defect detection using Vision-Language Models on edge devices.

Author: Pushkar Prashantrao Shinde
License: MIT
"""

import argparse
import time
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List

import torch
from PIL import Image
from transformers import AutoProcessor, LlavaForConditionalGeneration, BitsAndBytesConfig


class EdgeVLMInspector:
    """
    Vision-Language Model based industrial inspector.
    Performs zero-shot defect detection without task-specific training.
    """
    
    SUPPORTED_MODELS = {
        "llava-1.5-7b": "llava-hf/llava-1.5-7b-hf",
        "llava-1.5-13b": "llava-hf/llava-1.5-13b-hf",
    }
    
    DEFAULT_PROMPTS = {
        "general": "Describe any defects, damage, or anomalies you see in this image. Be specific about location and type.",
        "pcb": "Inspect this PCB/circuit board. List any defects including: solder bridges, missing components, burn marks, scratches, misaligned parts, or contamination.",
        "solder": "Examine the solder joints in this image. Identify any cold joints, bridges, insufficient solder, or oxidation.",
        "component": "Check if all components are properly placed. Note any missing, rotated, or damaged components.",
        "binary": "Is this item defective? Answer YES or NO, then explain why.",
    }
    
    def __init__(
        self,
        model_name: str = "llava-1.5-7b",
        quantize: bool = True,
        device: Optional[str] = None,
        cache_dir: Optional[str] = None,
    ):
        """
        Initialize the VLM Inspector.
        
        Args:
            model_name: Model to use (see SUPPORTED_MODELS)
            quantize: Whether to use 4-bit quantization for memory efficiency
            device: Device to run on ('cuda', 'cpu', or None for auto)
            cache_dir: Directory to cache model weights
        """
        self.model_name = model_name
        self.quantize = quantize
        self.cache_dir = cache_dir
        
        # Auto-detect device
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device
            
        print(f"[EdgeVLM] Initializing on device: {self.device}")
        print(f"[EdgeVLM] Quantization: {'4-bit' if quantize else 'disabled'}")
        
        self.model = None
        self.processor = None
        self._load_model()
        
    def _load_model(self):
        """Load the VLM model and processor."""
        model_id = self.SUPPORTED_MODELS.get(self.model_name, self.model_name)
        print(f"[EdgeVLM] Loading model: {model_id}")
        
        start_time = time.time()
        
        # Configure quantization for edge deployment
        if self.quantize and self.device == "cuda":
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_use_double_quant=True,
                bnb_4bit_quant_type="nf4",
            )
            self.model = LlavaForConditionalGeneration.from_pretrained(
                model_id,
                quantization_config=quantization_config,
                device_map="auto",
                cache_dir=self.cache_dir,
                torch_dtype=torch.float16,
            )
        else:
            self.model = LlavaForConditionalGeneration.from_pretrained(
                model_id,
                cache_dir=self.cache_dir,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                device_map="auto" if self.device == "cuda" else None,
            )
            if self.device == "cpu":
                self.model = self.model.to(self.device)
        
        self.processor = AutoProcessor.from_pretrained(model_id, cache_dir=self.cache_dir)
        
        load_time = time.time() - start_time
        print(f"[EdgeVLM] Model loaded in {load_time:.2f}s")
        
        # Report memory usage
        if self.device == "cuda":
            memory_gb = torch.cuda.memory_allocated() / 1e9
            print(f"[EdgeVLM] GPU memory used: {memory_gb:.2f} GB")
    
    def inspect(
        self,
        image: Image.Image | str | Path,
        prompt: Optional[str] = None,
        prompt_type: str = "pcb",
        max_tokens: int = 300,
        temperature: float = 0.2,
    ) -> Dict[str, Any]:
        """
        Inspect an image for defects.
        
        Args:
            image: PIL Image, file path, or Path object
            prompt: Custom inspection prompt (overrides prompt_type)
            prompt_type: Type of default prompt to use
            max_tokens: Maximum tokens in response
            temperature: Sampling temperature (lower = more deterministic)
            
        Returns:
            Dictionary with inspection results
        """
        # Load image if path provided
        if isinstance(image, (str, Path)):
            image_path = Path(image)
            if not image_path.exists():
                raise FileNotFoundError(f"Image not found: {image_path}")
            image = Image.open(image_path).convert("RGB")
            image_source = str(image_path)
        else:
            image_source = "PIL Image"
        
        # Select prompt
        if prompt is None:
            prompt = self.DEFAULT_PROMPTS.get(prompt_type, self.DEFAULT_PROMPTS["general"])
        
        # Format conversation for LLaVA
        conversation = [
            {
                "role": "user",
                "content": [
                    {"type": "image"},
                    {"type": "text", "text": prompt},
                ],
            },
        ]
        
        # Process inputs
        formatted_prompt = self.processor.apply_chat_template(conversation, add_generation_prompt=True)
        inputs = self.processor(
            text=formatted_prompt,
            images=image,
            return_tensors="pt",
        )
        
        # Move to device
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}
        
        # Generate response
        start_time = time.time()
        
        with torch.no_grad():
            output = self.model.generate(
                **inputs,
                max_new_tokens=max_tokens,
                do_sample=temperature > 0,
                temperature=temperature if temperature > 0 else None,
                pad_token_id=self.processor.tokenizer.eos_token_id,
            )
        
        inference_time = time.time() - start_time
        
        # Decode response
        generated_text = self.processor.decode(output[0], skip_special_tokens=True)
        
        # Extract assistant response (after the prompt)
        if "ASSISTANT:" in generated_text:
            response = generated_text.split("ASSISTANT:")[-1].strip()
        elif "assistant" in generated_text.lower():
            response = generated_text.split("assistant")[-1].strip()
        else:
            response = generated_text
        
        # Parse for defect detection
        response_lower = response.lower()
        has_defect = any(word in response_lower for word in [
            "defect", "damage", "missing", "broken", "scratch", "crack",
            "burn", "bridge", "misalign", "contamination", "corrosion",
            "fault", "error", "anomaly", "issue", "problem"
        ])
        
        # Check for explicit "no defect" statements
        if any(phrase in response_lower for phrase in [
            "no defect", "no visible defect", "no damage", "no issue",
            "appears normal", "looks good", "no anomal"
        ]):
            has_defect = False
        
        return {
            "image_source": image_source,
            "prompt": prompt,
            "response": response,
            "has_defect": has_defect,
            "inference_time_ms": round(inference_time * 1000, 2),
            "timestamp": datetime.now().isoformat(),
            "model": self.model_name,
            "quantized": self.quantize,
        }
    
    def batch_inspect(
        self,
        image_dir: str | Path,
        output_file: Optional[str] = None,
        prompt: Optional[str] = None,
        prompt_type: str = "pcb",
        extensions: List[str] = [".jpg", ".jpeg", ".png", ".bmp"],
    ) -> List[Dict[str, Any]]:
        """
        Inspect all images in a directory.
        
        Args:
            image_dir: Directory containing images
            output_file: Optional JSON file to save results
            prompt: Custom inspection prompt
            prompt_type: Type of default prompt
            extensions: Image file extensions to process
            
        Returns:
            List of inspection results
        """
        image_dir = Path(image_dir)
        if not image_dir.exists():
            raise FileNotFoundError(f"Directory not found: {image_dir}")
        
        # Find all images
        images = []
        for ext in extensions:
            images.extend(image_dir.glob(f"*{ext}"))
            images.extend(image_dir.glob(f"*{ext.upper()}"))
        
        images = sorted(set(images))
        print(f"[EdgeVLM] Found {len(images)} images to inspect")
        
        results = []
        defect_count = 0
        
        for i, image_path in enumerate(images, 1):
            print(f"[EdgeVLM] Inspecting {i}/{len(images)}: {image_path.name}")
            
            try:
                result = self.inspect(
                    image=image_path,
                    prompt=prompt,
                    prompt_type=prompt_type,
                )
                results.append(result)
                
                if result["has_defect"]:
                    defect_count += 1
                    print(f"  ⚠️  DEFECT DETECTED: {result['response'][:100]}...")
                else:
                    print(f"  ✓ No defects found")
                    
            except Exception as e:
                print(f"  ✗ Error: {e}")
                results.append({
                    "image_source": str(image_path),
                    "error": str(e),
                    "timestamp": datetime.now().isoformat(),
                })
        
        # Summary
        print(f"\n[EdgeVLM] Inspection complete:")
        print(f"  Total images: {len(images)}")
        print(f"  Defects found: {defect_count}")
        print(f"  Pass rate: {((len(images) - defect_count) / len(images) * 100):.1f}%")
        
        # Save results
        if output_file:
            output_path = Path(output_file)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w") as f:
                json.dump(results, f, indent=2)
            print(f"  Results saved to: {output_path}")
        
        return results


def main():
    parser = argparse.ArgumentParser(
        description="Edge VLM Industrial Inspector - Zero-shot defect detection"
    )
    parser.add_argument(
        "image",
        type=str,
        help="Image file or directory to inspect",
    )
    parser.add_argument(
        "--prompt", "-p",
        type=str,
        default=None,
        help="Custom inspection prompt",
    )
    parser.add_argument(
        "--type", "-t",
        type=str,
        default="pcb",
        choices=["general", "pcb", "solder", "component", "binary"],
        help="Inspection type (default: pcb)",
    )
    parser.add_argument(
        "--model", "-m",
        type=str,
        default="llava-1.5-7b",
        help="Model to use (default: llava-1.5-7b)",
    )
    parser.add_argument(
        "--no-quantize",
        action="store_true",
        help="Disable 4-bit quantization",
    )
    parser.add_argument(
        "--output", "-o",
        type=str,
        default=None,
        help="Output JSON file for results",
    )
    parser.add_argument(
        "--cpu",
        action="store_true",
        help="Force CPU inference",
    )
    
    args = parser.parse_args()
    
    # Initialize inspector
    inspector = EdgeVLMInspector(
        model_name=args.model,
        quantize=not args.no_quantize,
        device="cpu" if args.cpu else None,
    )
    
    # Check if input is file or directory
    input_path = Path(args.image)
    
    if input_path.is_file():
        # Single image inspection
        result = inspector.inspect(
            image=input_path,
            prompt=args.prompt,
            prompt_type=args.type,
        )
        
        print("\n" + "=" * 60)
        print("INSPECTION RESULT")
        print("=" * 60)
        print(f"Image: {result['image_source']}")
        print(f"Defect Detected: {'YES ⚠️' if result['has_defect'] else 'NO ✓'}")
        print(f"Inference Time: {result['inference_time_ms']} ms")
        print(f"\nAnalysis:\n{result['response']}")
        print("=" * 60)
        
        if args.output:
            with open(args.output, "w") as f:
                json.dump(result, f, indent=2)
            print(f"\nResult saved to: {args.output}")
            
    elif input_path.is_dir():
        # Batch inspection
        results = inspector.batch_inspect(
            image_dir=input_path,
            output_file=args.output,
            prompt=args.prompt,
            prompt_type=args.type,
        )
    else:
        print(f"Error: {input_path} is not a valid file or directory")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
