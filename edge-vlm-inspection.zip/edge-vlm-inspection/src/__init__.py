"""
Edge VLM Industrial Inspector
Zero-shot defect detection using Vision-Language Models.

Author: Pushkar Prashantrao Shinde
"""

from .inspector import EdgeVLMInspector

__version__ = "0.1.0"
__author__ = "Pushkar Prashantrao Shinde"
__all__ = ["EdgeVLMInspector"]
