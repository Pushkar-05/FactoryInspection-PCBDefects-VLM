# Edge VLM Industrial Inspector

**Zero-shot defect detection using Vision-Language Models on edge devices.**

No labeling. No training. Point a camera and ask.

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)
![Platform](https://img.shields.io/badge/Platform-Linux-orange.svg)

## The Problem

Traditional industrial inspection requires:
- Training separate ML models for each defect type
- Thousands of labeled images
- Weeks of data annotation
- Retraining when products change

**This approach doesn't scale.**

## The Solution

Vision-Language Models (VLMs) understand both images and natural language. Instead of training a model to detect "solder bridges," you simply ask:

```bash
python src/inspector.py circuit.jpg --prompt "Is there a solder bridge on this PCB?"
```

**Change the prompt, not the model.**

## Features

- 🚀 **Zero-shot inspection** — No training required
- 🔧 **4-bit quantization** — Runs on edge devices (26GB → 7GB memory)
- 📷 **Real-time camera support** — Live inspection with webcam
- 🏭 **Batch processing** — Inspect entire directories
- 📊 **JSON export** — Integration-ready results

## Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/edge-vlm-inspection.git
cd edge-vlm-inspection

# Create virtual environment
python -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Single Image Inspection

```bash
# Inspect a circuit board
python src/inspector.py path/to/circuit.jpg

# Custom prompt
python src/inspector.py path/to/image.jpg --prompt "Are there any scratches or burn marks?"

# Different inspection types
python src/inspector.py image.jpg --type solder      # Solder joint analysis
python src/inspector.py image.jpg --type component   # Component placement
python src/inspector.py image.jpg --type binary      # Simple YES/NO defect check
```

### Batch Inspection

```bash
# Inspect all images in a directory
python src/inspector.py ./images/ --output results.json
```

### Real-time Camera Inspection

```bash
# Start real-time inspector (press 'i' to inspect, 'q' to quit)
python src/realtime_inspector.py

# Specify camera
python src/realtime_inspector.py --camera 1
```

## Usage Examples

### PCB Inspection

```python
from src.inspector import EdgeVLMInspector

inspector = EdgeVLMInspector(quantize=True)

result = inspector.inspect(
    image="pcb_sample.jpg",
    prompt="Check this PCB for: solder bridges, missing components, burn marks, or scratches."
)

print(f"Defect detected: {result['has_defect']}")
print(f"Analysis: {result['response']}")
```

### Custom Manufacturing Inspection

```python
# Inspect any manufactured part
result = inspector.inspect(
    image="part.jpg",
    prompt="Inspect this machined part for surface defects, dimensional issues, or tooling marks."
)
```

### Binary Pass/Fail

```python
result = inspector.inspect(
    image="item.jpg",
    prompt_type="binary"  # Returns YES/NO with explanation
)
```

## Performance

| Configuration | Memory | Inference Time | Accuracy |
|--------------|--------|----------------|----------|
| LLaVA-7B (4-bit) | ~7 GB | ~2-3 sec | Baseline |
| LLaVA-13B (4-bit) | ~10 GB | ~4-5 sec | +5% |
| LLaVA-7B (FP16) | ~14 GB | ~1.5 sec | Baseline |

*Tested on NVIDIA RTX 3080. Times vary based on image size and prompt length.*

## Jetson Deployment

For NVIDIA Jetson (Orin/Xavier):

```bash
# Install PyTorch for Jetson
# See: https://forums.developer.nvidia.com/t/pytorch-for-jetson/

# Install with Jetson-specific optimizations
pip install -r requirements.txt

# Run with reduced memory footprint
python src/inspector.py image.jpg --model llava-1.5-7b
```

## API Reference

### EdgeVLMInspector

```python
inspector = EdgeVLMInspector(
    model_name="llava-1.5-7b",  # Model to use
    quantize=True,              # Enable 4-bit quantization
    device=None,                # Auto-detect (cuda/cpu)
    cache_dir=None,             # Model cache directory
)

result = inspector.inspect(
    image="path/to/image.jpg",  # Image path or PIL Image
    prompt=None,                # Custom prompt (optional)
    prompt_type="pcb",          # Default prompt type
    max_tokens=300,             # Max response length
    temperature=0.2,            # Sampling temperature
)
```

### Result Format

```json
{
    "image_source": "path/to/image.jpg",
    "prompt": "Inspect this PCB...",
    "response": "The PCB shows a potential solder bridge between pins 3 and 4...",
    "has_defect": true,
    "inference_time_ms": 2340.5,
    "timestamp": "2026-01-30T12:00:00",
    "model": "llava-1.5-7b",
    "quantized": true
}
```

## Built-in Prompts

| Type | Use Case |
|------|----------|
| `pcb` | Circuit board inspection (default) |
| `solder` | Solder joint quality |
| `component` | Component placement verification |
| `general` | Generic defect detection |
| `binary` | Simple pass/fail |

## Project Structure

```
edge-vlm-inspection/
├── src/
│   ├── inspector.py          # Core VLM inspector
│   └── realtime_inspector.py # Real-time camera interface
├── samples/                   # Sample images for testing
├── requirements.txt
├── README.md
└── LICENSE
```

## Why This Matters

Industrial machine vision is a $15B+ market still running on 2018 workflows:

1. **Collect** thousands of images
2. **Label** defects manually
3. **Train** a model
4. **Deploy** to production
5. **Repeat** when products change

VLMs collapse steps 1-4 into a single prompt. This isn't incremental improvement—it's a paradigm shift.

## Limitations

- **Speed**: VLMs are slower than optimized detection models for simple counting tasks
- **Consistency**: Natural language outputs may vary; use `temperature=0` for deterministic results
- **Domain specificity**: May need prompt engineering for highly specialized defects

## Roadmap

- [ ] Multi-camera synchronized inspection
- [ ] Defect localization with bounding boxes
- [ ] Integration with ROS2 for robotic inspection cells
- [ ] Custom fine-tuning pipeline for domain-specific defects
- [ ] Web dashboard for inspection management

## Author

**Pushkar Prashantrao Shinde**

- Robotics Vision Engineer
- NYU Tandon School of Engineering
- [LinkedIn](https://www.linkedin.com/in/pushkar-shinde/)

## License

MIT License - see [LICENSE](LICENSE) for details.

---

*Built with the belief that factory inspection shouldn't require an ML team.*
