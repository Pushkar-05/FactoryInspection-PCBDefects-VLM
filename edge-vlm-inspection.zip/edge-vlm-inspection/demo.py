#!/usr/bin/env python3
"""
Quick Demo Script
Run this to test the Edge VLM Inspector with a sample image.

Usage:
    python demo.py [image_path]
    
If no image is provided, it will create a synthetic test pattern.
"""

import sys
import json
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from PIL import Image, ImageDraw
import numpy as np


def create_sample_image():
    """Create a synthetic PCB-like test image."""
    print("[Demo] Creating synthetic test image...")
    
    # Create a green PCB-like background
    img = Image.new('RGB', (640, 480), color=(34, 85, 51))
    draw = ImageDraw.Draw(img)
    
    # Add some "traces" (copper lines)
    for i in range(5):
        y = 50 + i * 80
        draw.line([(50, y), (590, y)], fill=(184, 134, 11), width=3)
    
    for i in range(8):
        x = 80 + i * 70
        draw.line([(x, 30), (x, 450)], fill=(184, 134, 11), width=2)
    
    # Add some "components" (rectangles)
    components = [
        (100, 100, 150, 130),
        (200, 180, 280, 220),
        (350, 100, 400, 150),
        (450, 250, 520, 300),
        (150, 350, 230, 400),
    ]
    
    for comp in components:
        draw.rectangle(comp, fill=(20, 20, 20), outline=(100, 100, 100))
    
    # Add a "defect" - a solder bridge (blob connecting two traces)
    draw.ellipse((280, 125, 320, 145), fill=(192, 192, 192))
    
    # Add another defect - missing component outline
    draw.rectangle((400, 350, 470, 400), outline=(255, 0, 0), width=2)
    draw.text((405, 360), "MISSING", fill=(255, 0, 0))
    
    # Save the test image
    test_path = Path("samples/test_pcb.png")
    test_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(test_path)
    
    print(f"[Demo] Test image saved to: {test_path}")
    return test_path


def run_demo(image_path=None):
    """Run the demo inspection."""
    
    print("=" * 60)
    print("EDGE VLM INDUSTRIAL INSPECTOR - DEMO")
    print("=" * 60)
    
    # Get or create test image
    if image_path is None:
        image_path = create_sample_image()
    else:
        image_path = Path(image_path)
        if not image_path.exists():
            print(f"[Error] Image not found: {image_path}")
            return 1
    
    print(f"\n[Demo] Image: {image_path}")
    print("[Demo] Loading VLM model (this may take a minute on first run)...\n")
    
    try:
        from inspector import EdgeVLMInspector
        
        # Initialize inspector
        inspector = EdgeVLMInspector(
            model_name="llava-1.5-7b",
            quantize=True,
        )
        
        # Run inspection with different prompts
        prompts = [
            ("PCB Inspection", "pcb", None),
            ("Binary Check", "binary", None),
            ("Custom", None, "Describe any visual anomalies, defects, or quality issues in this image."),
        ]
        
        print("\n" + "=" * 60)
        print("INSPECTION RESULTS")
        print("=" * 60)
        
        for name, prompt_type, custom_prompt in prompts:
            print(f"\n--- {name} ---")
            
            result = inspector.inspect(
                image=image_path,
                prompt=custom_prompt,
                prompt_type=prompt_type or "general",
            )
            
            print(f"Defect Detected: {'YES ⚠️' if result['has_defect'] else 'NO ✓'}")
            print(f"Inference Time: {result['inference_time_ms']} ms")
            print(f"Analysis: {result['response'][:300]}...")
        
        # Save results
        results_path = Path("samples/demo_results.json")
        with open(results_path, "w") as f:
            json.dump(result, f, indent=2)
        print(f"\n[Demo] Results saved to: {results_path}")
        
        print("\n" + "=" * 60)
        print("DEMO COMPLETE")
        print("=" * 60)
        print("\nNext steps:")
        print("  1. Try with your own circuit board image:")
        print("     python src/inspector.py your_image.jpg")
        print("  2. Run real-time camera inspection:")
        print("     python src/realtime_inspector.py")
        print("  3. Batch process a directory:")
        print("     python src/inspector.py ./images/ -o results.json")
        
        return 0
        
    except ImportError as e:
        print(f"[Error] Missing dependency: {e}")
        print("\nInstall requirements first:")
        print("  pip install -r requirements.txt")
        return 1
    except Exception as e:
        print(f"[Error] {e}")
        return 1


if __name__ == "__main__":
    image_arg = sys.argv[1] if len(sys.argv) > 1 else None
    exit(run_demo(image_arg))
