# Sample Images

Place your test images here.

## Supported formats
- `.jpg` / `.jpeg`
- `.png`
- `.bmp`

## Running the demo

```bash
# From project root
python demo.py

# Or with your own image
python demo.py samples/your_circuit.jpg
```

## Sample images to test with

1. Circuit boards / PCBs
2. Solder joints
3. Manufactured parts
4. Any item requiring visual inspection

The VLM will analyze whatever you show it - no training required.
